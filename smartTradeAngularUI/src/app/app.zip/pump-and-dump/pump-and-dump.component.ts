import { Component, EventEmitter, Output, inject } from '@angular/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RuleConfigDialogComponent } from './rule-config-dialog/rule-config-dialog.component';
import { ManualResponse } from './../services/rule-engine.service';

@Component({
  selector: 'app-rule-config-button',
  standalone: true,
  imports: [MatDialogModule, MatButtonModule, MatIconModule],
  template: `
    <button mat-raised-button color="primary" class="cta" (click)="open()">
      <mat-icon>tune</mat-icon>
      Configure your Rules
    </button>
  `,
  styles: [
    `
      .cta {
        font-weight: 600;
        border-radius: 10px;
        padding: 10px 18px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
      }
    `,
  ],
})
export class PumpAndDumpComponent {
  private dialog = inject(MatDialog);

  @Output() executed = new EventEmitter<ManualResponse>();

  open() {
    this.dialog
      .open(RuleConfigDialogComponent, {
        width: '720px',
        maxWidth: '95vw',
        autoFocus: 'first-tabbable',
        panelClass: 'rules-dialog',
      })
      .afterClosed()
      .subscribe((resp?: ManualResponse) => {
        if (resp) {
          this.executed.emit(resp);
        }
      });
  }
}
